#ifndef __EXTEND_H
#define __EXTEND_H	 

#include "sys.h"



void EXTEND_Main(void);

#endif
