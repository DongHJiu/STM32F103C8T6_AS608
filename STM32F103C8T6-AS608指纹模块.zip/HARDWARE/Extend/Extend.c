#include <string.h>
#include <stdio.h>
#include "EXTEND.h"
#include "OLED.h"
#include "delay.h"
#include "AS608.h"
#include "key.h"
#include "IIC.h"

unsigned char NUM_NO_Data[80];         //δ����Ա���
unsigned char Restroom_Data[80];       //�ϲ�����Ա
unsigned char Restroom_Data_TEW[80];       //�ϲ�����Ա2
//SysPara AS608Para;//ָ��ģ��AS608����

void EXTEND_Main(void);          //���˵�
void EXTEND_Main_Screen(void);   //������
void EXTEND_checking_in(void);   //���ڴ�
void EXTEND_restroom(void);      //�ϲ�����
void Clock_in_State(void);


/**
  * @brief  ���ڴ򿨿�ʼ
  * @param  ��
  * @retval ��  
  */
void Clock_in_Start(void)
{
  SearchResult seach;
  u8 ensure;
  char str[20];
	  OLED_Clear();
/* ----------------------------------------------------------------------------------------------------------------- */	
  while(key_num != 4)
  {
		OLED_ShowCharChinese(1,1,17);OLED_ShowCharChinese(1,3,19);
		OLED_ShowCharChinese(1,5,21);OLED_ShowCharChinese(1,7,5);	

	  OLED_ShowString(4,1,"K4:");      //����
	  OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);
    key_num = KEY_Scan();
    ensure = PS_GetImage();
		
    if(ensure == 0x00) 
    {
			printf("��ȡͼ��ɹ� \r\n");
      ensure = PS_GenChar(CharBuffer1);
				OLED_Clear();
/* ----------------------------------------------------------------------------------------------------------------- */			
      if(ensure == 0x00) 
      {
				printf("���������ɹ� \r\n");
        ensure = PS_HighSpeedSearch(CharBuffer1, 0, 99, &seach);					
/* ----------------------------------------------------------------------------------------------------------------- */				
        if(ensure == 0x00) 
        {
					printf("�򿨳ɹ� \r\n");
			    OLED_ShowCharChinese(1,1,91);OLED_ShowCharChinese(1,3,93);
			    OLED_ShowCharChinese(1,5,37);OLED_ShowCharChinese(1,7,39);							
					 OLED_ShowString(1,10,"ID:");
/* ----------------------------------------------------------------------------------------------------------------- */					
          sprintf(str, " ָ��ID:%d  ", seach.pageID);				
					  OLED_ShowNum(1,13,seach.pageID,3);	
					
					  OLED_ShowString(4,1,"K4:");
					  OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);
/* ----------------------------------------------------------------------------------------------------------------- */
					//NUM_Data[seach.pageID]=1;
					At24c02Write(seach.pageID,1);
          delay_ms(1000);delay_ms(1000);delay_ms(1000);
					//break;
        }
        else
        {
					printf("��֤ʧ�� \r\n");
					  OLED_ShowCharChinese(3,1,13);OLED_ShowCharChinese(3,3,15);
					  OLED_ShowCharChinese(3,5,77);OLED_ShowCharChinese(3,7,79);
					
					  //OLED_ShowString(4,1,"K3:");
					  //OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);	
/* ----------------------------------------------------------------------------------------------------------------- */					
					delay_ms(1000);delay_ms(1000);delay_ms(1000);
					//break;
        }
      }
      else
			{
				
			};
			OLED_Clear();
    }
  }
	 EXTEND_checking_in();
/* ----------------------------------------------------------------------------------------------------------------- */	
}

//��һҳ
void Clock_in_panel(void){
	unsigned char i=9;
	unsigned char Data=0;
	unsigned char NUM=0;
	unsigned char NUM_NO = 0;
//	unsigned char KEY_A = 0;	
	
	unsigned char I_A=0;
	unsigned char I_B=0;
	   //unsigned char I_C=2;
	unsigned char I_D=0;
	unsigned char I_E=0;
	while(i<50){                     
		Data=At24c02Read(i);
		if(Data){
			NUM++;
		}
		else{
			NUM_NO++;
			NUM_NO_Data[NUM_NO]=i;
		}
		i++;
	}
	OLED_Clear();
//	OLED_ShowCharChinese(1,1,127);OLED_ShowCharChinese(1,3,91);
//	OLED_ShowCharChinese(1,5,93);
//	OLED_ShowNum(1,7,NUM,3);
//	OLED_ShowCharChinese(1,10,111);

	OLED_ShowCharChinese(1,1,129);OLED_ShowCharChinese(1,3,91);
	OLED_ShowCharChinese(1,5,93);OLED_ShowString(1,7,":");  	
		NUM_NO=NUM_NO-8;
		I_A=NUM_NO;	
		while(I_A>0){
		I_A=I_A-1;
		I_B=NUM_NO-I_A;
			if(I_B<=3){
				OLED_ShowNum(1,8+I_D,NUM_NO_Data[I_B],2);	
				OLED_ShowString(1,8+I_D+2,":");
				I_D=I_D+3;
			}
			if(I_B>3 && I_E==0 ){
				I_D=1;
			}
			if(9>I_B && I_B>3){                      
				OLED_ShowNum(2,I_D,NUM_NO_Data[I_B],2);	   
				OLED_ShowString(2,I_D+2,":");
				I_D=I_D+3;
				I_E=1;
			}				
	}	

	
	  OLED_ShowString(4,1,"K4:");
	  OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);		
		
		while(KEY_Scan() != 4){;}
		Clock_in_State();	
}



/**
  * @brief  �鿴�����
  * @param  ��
  * @retval ��
  */
void Clock_in_State(void){
	unsigned char i=1;
	unsigned char Data=0;
	unsigned char NUM=0;
	unsigned char NUM_NO = 0;
	unsigned char KEY_A = 0;	
	
	unsigned char I_A=0;
	unsigned char I_B=0;
	   //unsigned char I_C=2;
	unsigned char I_D=0;
	unsigned char I_E=0;
	while(i<50){                     
		Data=At24c02Read(i);
		if(Data){
			NUM++;
		}
		else{
			NUM_NO++;
			NUM_NO_Data[NUM_NO]=i;
		}
		i++;
	}
	OLED_Clear();
	OLED_ShowCharChinese(1,1,127);OLED_ShowCharChinese(1,3,91);
	OLED_ShowCharChinese(1,5,93);
	OLED_ShowNum(1,7,NUM,3);
	OLED_ShowCharChinese(1,10,111);

	OLED_ShowCharChinese(2,1,129);OLED_ShowCharChinese(2,3,91);
	OLED_ShowCharChinese(2,5,93);OLED_ShowString(2,7,":");  	
	
		I_A=NUM_NO;	
		while(I_A>0){
		I_A=I_A-1;
		I_B=NUM_NO-I_A;
			if(I_B<=3){
				OLED_ShowNum(2,8+I_D,NUM_NO_Data[I_B],2);	
				OLED_ShowString(2,8+I_D+2,":");
				I_D=I_D+3;
			}
			if(I_B>3 && I_E==0 ){
				I_D=1;
			}
			if(9>I_B && I_B>3){                      
				OLED_ShowNum(3,I_D,NUM_NO_Data[I_B],2);	   
				OLED_ShowString(3,I_D+2,":");
				I_D=I_D+3;
				I_E=1;
			}				
	}	
		
	  OLED_ShowString(4,8,"K3:");
	  OLED_ShowCharChinese(4,11,135);OLED_ShowCharChinese(4,13,137);			
		OLED_ShowCharChinese(4,15,139);
	
	  OLED_ShowString(4,1,"K4:");
	  OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);		
	
	while(KEY_A != 3 && KEY_A != 4){
		KEY_A = KEY_Scan();
	}
	if(KEY_A == 3){
		KEY_A = 0;
		Clock_in_panel(); 
	}
	if(KEY_A == 4){
		KEY_A = 0;
		EXTEND_checking_in();
	}		
	
	while(KEY_Scan() != 4){;}
	  EXTEND_checking_in();
				
}


/**
  * @brief  ��մ򿨼�¼
  * @param  ��
  * @retval ��
  */
void Clock_in_Delete(void){
	int i;
	OLED_Clear();
	OLED_ShowString(1,1,"---");
	for(i=0;i<50;i++){
		At24c02Write(i,0);
	}
	OLED_ShowCharChinese(1,1,117);OLED_ShowCharChinese(1,3,119);
	OLED_ShowCharChinese(1,5,37);OLED_ShowCharChinese(1,7,39);
	
	OLED_ShowString(4,1,"K4:");
	OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);		
	while(KEY_Scan() != 4){;}
	EXTEND_checking_in();
	delay_ms(100);
}

/**
  * @brief  EXTEND������
  * @param  ��
  * @retval ��  
  */
void EXTEND_Main_Screen(void){
	OLED_Clear();
	OLED_ShowString(1,1,"K1:");     //���ڴ�
	OLED_ShowCharChinese(1,4,87);OLED_ShowCharChinese(1,6,89);
	OLED_ShowCharChinese(1,8,91);OLED_ShowCharChinese(1,10,93);
	
	OLED_ShowString(2,1,"K2:");     //�ϲ�����
	OLED_ShowCharChinese(2,4,95);OLED_ShowCharChinese(2,6,97);OLED_ShowCharChinese(2,8,99);
	OLED_ShowCharChinese(2,10,91);OLED_ShowCharChinese(2,12,93);	
	
	OLED_ShowString(3,1,"K4:");      //����
	OLED_ShowCharChinese(3,4,47);OLED_ShowCharChinese(3,6,49);
	
}

/**
  * @brief  ���ڴ򿨽���
  * @param  ��
  * @retval ��  
  */
void EXTEND_checking_in(void){
	OLED_Clear();
	OLED_ShowString(1,1,"K1:");     //���ڴ򿨿�ʼ
	OLED_ShowCharChinese(1,4,87);OLED_ShowCharChinese(1,6,89);
	OLED_ShowCharChinese(1,8,91);OLED_ShowCharChinese(1,10,93);
	OLED_ShowCharChinese(1,12,101);OLED_ShowCharChinese(1,14,103);

  OLED_ShowString(2,1,"K2:");     //�鿴�����
	OLED_ShowCharChinese(2,4,105);OLED_ShowCharChinese(2,6,107);
	OLED_ShowCharChinese(2,8,91);OLED_ShowCharChinese(2,10,93);
	OLED_ShowCharChinese(2,12,123);OLED_ShowCharChinese(2,14,125);	
	

  OLED_ShowString(3,1,"K3:");      //���
	OLED_ShowCharChinese(3,4,117);OLED_ShowCharChinese(3,6,119);	
	
  OLED_ShowString(4,1,"K4:");      //����
	OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);

	while(1){
			if(KEY_Scan() == 1){
			key_num = 0;
			Clock_in_Start();
			break;	
		}
			if(KEY_Scan() == 2){
			key_num = 0;
			Clock_in_State();
			break;	
		}
			if(KEY_Scan() == 3){
			key_num = 0;
			Clock_in_Delete();
			break;	
		}				
			if(KEY_Scan() == 4){
			key_num = 0;
			EXTEND_Main();
			break;	
		}		
	}
}

/**
  * @brief  �ϲ����򿨿�ʼ
  * @param  ��
  * @retval ��  
  */
void Restroom_Start(void){
  SearchResult seach;
  u8 ensure;
	int i_A=1;
  char str[20];
	  OLED_Clear();
/* ----------------------------------------------------------------------------------------------------------------- */	
  while(key_num != 4)
  {
		OLED_ShowCharChinese(1,1,17);OLED_ShowCharChinese(1,3,19);
		OLED_ShowCharChinese(1,5,21);OLED_ShowCharChinese(1,7,5);	

	  OLED_ShowString(4,1,"K4:");      //����
	  OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);
    key_num = KEY_Scan();
    ensure = PS_GetImage();
		
    if(ensure == 0x00) 
    {
			printf("��ȡͼ��ɹ� \r\n");
      ensure = PS_GenChar(CharBuffer1);
				OLED_Clear();
/* ----------------------------------------------------------------------------------------------------------------- */			
      if(ensure == 0x00) 
      {
				printf("���������ɹ� \r\n");
        ensure = PS_HighSpeedSearch(CharBuffer1, 0, 99, &seach);					
/* ----------------------------------------------------------------------------------------------------------------- */				
        if(ensure == 0x00) 
        {
					printf("�򿨳ɹ� \r\n");
			    OLED_ShowCharChinese(1,1,91);OLED_ShowCharChinese(1,3,93);
			    OLED_ShowCharChinese(1,5,37);OLED_ShowCharChinese(1,7,39);							
					 OLED_ShowString(1,10,"ID:");
/* ----------------------------------------------------------------------------------------------------------------- */					
          sprintf(str, " ָ��ID:%d  ", seach.pageID);				
					  OLED_ShowNum(1,13,seach.pageID,3);	
					
					  OLED_ShowString(4,1,"K4:");
					  OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);
/* ----------------------------------------------------------------------------------------------------------------- */					
					
					//Restroom_Data[i_A]=seach.pageID;
					At24c02Write(i_A+100,seach.pageID);
					i_A++;
					
          delay_ms(1000);delay_ms(1000);delay_ms(1000);
					//break;
        }
        else
        {
					printf("��֤ʧ�� \r\n");
					  OLED_ShowCharChinese(3,1,13);OLED_ShowCharChinese(3,3,15);
					  OLED_ShowCharChinese(3,5,77);OLED_ShowCharChinese(3,7,79);
					
/* ----------------------------------------------------------------------------------------------------------------- */					
					delay_ms(1000);delay_ms(1000);delay_ms(1000);
					//break;
        }
      }
      else
			{
				
			};
			OLED_Clear();
    }
  }
	 EXTEND_restroom();	
}

/**
  * @brief  �鿴ȥ������Ա
  * @param  ��
  * @retval ��
  */
void restroom_IN(void){
	unsigned char i=1;
	unsigned char x=1;	
	unsigned char Data=0;
//	unsigned char NUM=0;
//	unsigned char NUM_NO = 0;
	
	unsigned char I_A=0;
	unsigned char I_B=0;
	   //unsigned char I_C=2;
	unsigned char I_D=1;
	unsigned char I_E=0;
	while(i<50){                     
		Data=At24c02Read(i+100);
		if(Data){
			Restroom_Data_TEW[x]=Data;
			x++;
		}
		i++;
	}
	OLED_Clear();  	
	
		I_A=x;	
		while(I_A>1){
		I_A=I_A-1;
		I_B=x-I_A;
			if(I_B<=6){
				OLED_ShowNum(1,I_D,Restroom_Data_TEW[I_B],2);	
				OLED_ShowString(1,I_D+2,":");
				I_D=I_D+3;
			}
			if(I_B>6 && I_E==0 ){
				I_D=1;
			}
			if(11>I_B && I_B>6){                      
				OLED_ShowNum(2,I_D,Restroom_Data_TEW[I_B],2);	   
				OLED_ShowString(2,I_D+2,":");
				I_D=I_D+3;
				I_E=1;
			}				
	}	
	
	  OLED_ShowString(4,1,"K4:");
	  OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);		
	
	while(KEY_Scan() != 4){;}
	  EXTEND_restroom();	
}

/**
  * @brief  �ϲ���������֤
  * @param  ��
  * @retval ��  
  */
void Restroom_Return(void){
  SearchResult seach;
  u8 ensure;
	int i_A=0;
	int i_B=100;	
  char str[20];
	  OLED_Clear();
/* ----------------------------------------------------------------------------------------------------------------- */	
  while(key_num != 4)
  {
		OLED_ShowCharChinese(1,1,17);OLED_ShowCharChinese(1,3,19);
		OLED_ShowCharChinese(1,5,21);OLED_ShowCharChinese(1,7,5);	

	  OLED_ShowString(4,1,"K4:");      //����
	  OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);
    key_num = KEY_Scan();
    ensure = PS_GetImage();
		
    if(ensure == 0x00) 
    {
			printf("��ȡͼ��ɹ� \r\n");
      ensure = PS_GenChar(CharBuffer1);
				OLED_Clear();
/* ----------------------------------------------------------------------------------------------------------------- */			
      if(ensure == 0x00) 
      {
				printf("���������ɹ� \r\n");
        ensure = PS_HighSpeedSearch(CharBuffer1, 0, 99, &seach);					
/* ----------------------------------------------------------------------------------------------------------------- */				
        if(ensure == 0x00) 
        {
/* ----------------------------------------------------------------------------------------------------------------- */					
					while(i_B){						
						if(At24c02Read(i_A+100) == seach.pageID){
							At24c02Write(i_A+100,0);
						}
						i_A++;
						i_B--;
					}
					
					printf("�򿨳ɹ� \r\n");
			    OLED_ShowCharChinese(1,1,131);OLED_ShowCharChinese(1,3,133);
			    OLED_ShowCharChinese(1,5,37);OLED_ShowCharChinese(1,7,39);							
					 OLED_ShowString(1,10,"ID:");
/* ----------------------------------------------------------------------------------------------------------------- */					
          sprintf(str, " ָ��ID:%d  ", seach.pageID);				
					  OLED_ShowNum(1,13,seach.pageID,3);	
					
					  OLED_ShowString(4,1,"K4:");
					  OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);					
					
          delay_ms(1000);delay_ms(1000);delay_ms(500);
					//break;
        }
        else
        {
					printf("��֤ʧ�� \r\n");
					  OLED_ShowCharChinese(3,1,13);OLED_ShowCharChinese(3,3,15);
					  OLED_ShowCharChinese(3,5,77);OLED_ShowCharChinese(3,7,79);
					
/* ----------------------------------------------------------------------------------------------------------------- */					
					delay_ms(1000);delay_ms(1000);delay_ms(1000);
					//break;
        }
      }
      else
			{
				
			};
			OLED_Clear();
    }
  }
	 EXTEND_restroom();	
}

/**
  * @brief  �ϲ����򿨽���
  * @param  ��
  * @retval ��  
  */
void EXTEND_restroom(void){
	OLED_Clear();
	OLED_ShowString(1,1,"K1:");      //�ϲ�����
	OLED_ShowCharChinese(1,4,95);OLED_ShowCharChinese(1,6,97);OLED_ShowCharChinese(1,8,99);
	OLED_ShowCharChinese(1,10,91);OLED_ShowCharChinese(1,12,93);	
	
	OLED_ShowString(2,1,"K2:");      //��ȥ������Ա
	OLED_ShowCharChinese(2,4,115);OLED_ShowCharChinese(2,6,121);
	OLED_ShowCharChinese(2,8,97);OLED_ShowCharChinese(2,10,99);
  OLED_ShowCharChinese(2,12,111);OLED_ShowCharChinese(2,14,113);
	
	OLED_ShowString(3,1,"K3:");      //������֤
	OLED_ShowCharChinese(3,4,47);OLED_ShowCharChinese(3,6,49);
	OLED_ShowCharChinese(3,8,13);OLED_ShowCharChinese(3,10,15);

  OLED_ShowString(4,1,"K4:");      //����
	OLED_ShowCharChinese(4,4,47);OLED_ShowCharChinese(4,6,49);	
	
	while(1){
			if(KEY_Scan() == 1){
			key_num = 0;
			Restroom_Start();
			break;	
		}		
			if(KEY_Scan() == 2){
			key_num = 0;
			restroom_IN();
			break;	
		}						
			if(KEY_Scan() == 3){
			key_num = 0;
			Restroom_Return();
			break;	
		}				
			if(KEY_Scan() == 4){
			key_num = 0;
			EXTEND_Main();
			break;	
		}
	}	
}


/**
  * @brief  EXTEND��������ƺ���
  * @param  ��
  * @retval ��  
  */
void EXTEND_Main(void){
	EXTEND_Main_Screen();
	
	while(1){
		if(KEY_Scan() == 1){
			key_num = 0;
			delay_ms(15);
			EXTEND_checking_in();
			break;
		}
		if(KEY_Scan() == 2){
			key_num = 0;
			EXTEND_restroom();
			break;
		}
		if(KEY_Scan() == 4){
			key_num = 0;
			MAIN_OLED();
			break;
		}		
	}
}
