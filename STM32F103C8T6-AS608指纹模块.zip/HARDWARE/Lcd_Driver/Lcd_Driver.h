

/*#define   BLACK     0x0000          ��ɫ    0,   0,   0
#define   NAVY      0x000F          ����ɫ  0,   0, 127
#define   DGREEN    0x03E0          ����ɫ  0,  127,  0
#define   DCYAN     0x03EF          ����ɫ  0,  127, 127       
#define   MAROON    0x7800          ���ɫ  127,   0,   0      
#define   PURPLE    0x780F          ��ɫ    127,   0, 127      
#define   OLIVE     0x7BE0          �����  127, 127,   0      
#define   LGRAY     0xC618          �Ұ�ɫ  192, 192, 192      
#define   DGRAY     0x7BEF          ���ɫ  127, 127, 127      
#define   BLUE      0x001F          ��ɫ    0,   0, 255        
#define   GREEN     0x07E0          ��ɫ    0, 255,   0        
#define   CYAN      0x07FF          ��ɫ    0, 255, 255        
#define   RED       0xF800          ��ɫ    255,   0,   0      
#define   MAGENTA   0xF81F          Ʒ��    255,   0, 255      
#define   YELLOW    0xFFE0          ��ɫ    255, 255, 0        
#define   WHITE     0xFFFF          ��ɫ    255, 255, 255 */

#define RED  	0xf800
#define GREEN	0x07e0
#define BLUE 	0x001f
#define WHITE	0xffff
#define BLACK	0x0000
#define YELLOW  0xFFE0
#define GRAY0   0xEF7D   	    //��ɫ0      3165 00110 001011 00101
#define GRAY1   0x8410      	//��ɫ1      00000 000000 00000
#define GRAY2   0x4208      	//��ɫ2      1111111111011111




#define LCD_CTRL   	  	GPIOB		//����TFT���ݶ˿�
#define LCD_LED        	GPIO_Pin_9  //MCU_PB9--->>TFT --BL
#define LCD_RS         	GPIO_Pin_6	//PB11--->>TFT --RS/DC
#define LCD_CS        	GPIO_Pin_7  //MCU_PB11--->>TFT --CS/CE
#define LCD_RST     	  GPIO_Pin_12	//PB10--->>TFT --RST
#define LCD_SCL        	GPIO_Pin_13	//PB13--->>TFT --SCL/SCK
#define LCD_SDA        	GPIO_Pin_15	//PB15 MOSI--->>TFT --SDA/DIN

#define LCD_CTRL_C   	  	GPIOC


//#define LCD_CS_SET(x) LCD_CTRL->ODR=(LCD_CTRL->ODR&~LCD_CS)|(x ? LCD_CS:0)

//Һ�����ƿ���1�������궨��
#define	LCD_CS_SET  	LCD_CTRL_C->BSRR=LCD_CS    
#define	LCD_RS_SET  	LCD_CTRL_C->BSRR=LCD_RS    
#define	LCD_SDA_SET  	LCD_CTRL->BSRR=LCD_SDA    
#define	LCD_SCL_SET  	LCD_CTRL->BSRR=LCD_SCL    
#define	LCD_RST_SET  	LCD_CTRL->BSRR=LCD_RST    
#define	LCD_LED_SET  	LCD_CTRL->BSRR=LCD_LED   

//Һ�����ƿ���0�������궨��
#define	LCD_CS_CLR  	LCD_CTRL_C->BRR=LCD_CS    
#define	LCD_RS_CLR  	LCD_CTRL_C->BRR=LCD_RS    
#define	LCD_SDA_CLR  	LCD_CTRL->BRR=LCD_SDA    
#define	LCD_SCL_CLR  	LCD_CTRL->BRR=LCD_SCL    
#define	LCD_RST_CLR  	LCD_CTRL->BRR=LCD_RST    
#define	LCD_LED_CLR  	LCD_CTRL->BRR=LCD_LED 


#define LCD_DATAOUT(x) LCD_DATA->ODR=x; //�������
#define LCD_DATAIN     LCD_DATA->IDR;   //��������

#define LCD_WR_DATA(data){\
LCD_RS_SET;\
LCD_CS_CLR;\
LCD_DATAOUT(data);\
LCD_WR_CLR;\
LCD_WR_SET;\
LCD_CS_SET;\
} 



void LCD_GPIO_Init(void);
void Lcd_WriteIndex(u8 Index);
void Lcd_WriteData(u8 Data);
void Lcd_WriteReg(u8 Index,u8 Data);
u16 Lcd_ReadReg(u8 LCD_Reg);
void Lcd_Reset(void);
void Lcd_Init(void);
void Lcd_Clear(u16 Color);
void Lcd_SetXY(u16 x,u16 y);
void Gui_DrawPoint(u16 x,u16 y,u16 Data);
unsigned int Lcd_ReadPoint(u16 x,u16 y);
void Lcd_SetRegion(u16 x_start,u16 y_start,u16 x_end,u16 y_end);
void LCD_WriteData_16Bit(u16 Data);

