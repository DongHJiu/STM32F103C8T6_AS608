#ifndef __IIC_H
#define __IIC_H


void First_I2C_GPIO(void);
void At24c02Write(unsigned char addr,unsigned char dat);
unsigned char At24c02Read(unsigned char addr);



#endif
