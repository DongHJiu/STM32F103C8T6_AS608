#ifndef __CONFIG_H
#define __CONFIG_H

#include "delay.h"
#include "sys.h"

#include "led.h"
#include "Key.h"
#include "usart.h"	 	
#include "wdg.h"
#include "timer.h"
#include "QDTFT_demo.h"
#include "Lcd_Driver.h"
#include "GUI.h"
#include "as608.h"
#include "usart3.h"

void TIM3_Int_Init(u16 arr,u16 psc);
int err = 0;

#endif
